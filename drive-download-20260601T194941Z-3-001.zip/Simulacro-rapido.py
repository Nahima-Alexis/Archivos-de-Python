import os
os.system("cls")

vehiculo = input("¿Qué vehículo conduces? (escribe 'auto' o 'camion'): ")
precio_total = 2000

if vehiculo == "camion":
    precio_total += 1500
else: #Puedo dejarlo sin else tambien.
    precio_total = 2000 

print(f"El total a pagar es: ${precio_total}")

dinero_entregado = int(input("\n¿Con cuánto dinero vas a pagar?: "))


if dinero_entregado >= precio_total:
    vuelto = dinero_entregado - precio_total
    print(f"El vuelto es: {vuelto}")
else:
    print("Falta dinero.\nNo puedes pasar.")
