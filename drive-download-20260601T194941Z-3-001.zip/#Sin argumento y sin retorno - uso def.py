#Sin argumento y sin retorno
import os
os.system("cls")

def abrir_cafeteria():
    print("La cafeteria esta abierta.")

abrir_cafeteria()