import os
os.system("cls")

#🛒 Simulacro 1: El Carrito de Compras Tecnológico
# 1. INPUT (Entradas)
# Pedir precio_1, precio_2, precio_3
print("----Bienvenido al Carrito de Compras Tecnológico----")
precio_1 = int(input("Ingresa el monto del primer producto\n--> Aquí: "))
precio_2 = int(input("Ingresa el monto del segundo producto\n--> Aquí: "))
precio_3 = int(input("Ingresa el monto del tercer producto\n--> Aquí: "))
# Crear contadores: pares = 0, impares = 0
pares = 0
impares = 0
# 2. PROCESO (If/Else y Matemáticas)
# Evaluar si precio_1 % 2 == 0 para sumar a los contadores (repetir para los 3)
if precio_1 % 2 == 0:
    pares += 1
else:
    impares += 1
    
if precio_2 % 2 == 0:
    pares += 1
else:
    impares += 1
    
if precio_3 % 2 == 0:
    pares += 1
else:
    impares += 1
        
# Sumar los 3 precios en un total
total_compra = precio_1 + precio_2 + precio_3

# Evaluar si el total > 50000 para calcular el descuento y restarlo
if total_compra > 50000:
    descuento = total_compra * 0.2
    total_a_pagar = total_compra - descuento
    print(f"¡Felicidades!\nHas ganado un descuento de 20%.\nTotal a pagar con el descuento:\n--> {total_a_pagar:.1f}")
else:
    print(f"El total a pagar es:\n--> {total_compra:.1f}")
# 3. OUTPUT (Salidas)
# Hacer los print con f"" de los contadores y el total final (usando round o formateo para 1 decimal)
print(f"\n~Resumen de productos~\nPrecios pares: {pares}\nPrecios impares: {impares}")