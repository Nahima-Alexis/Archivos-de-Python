#Menú de suma y resta
opcion = 0
while opcion != 3:
    print("Bienvenido al programa. Las opciones son las siguientes:")
    print("1. Sumar")
    print("2. Restar")
    print("3. Salir")
    
    opcion = int(input("Elige una opción: "))

    if opcion == 1:
        print("Elegiste sumar")
        numero1 = int(input("Ingresa el primer número: "))
        numero2 = int(input("Ingresa el segundo número: "))
        resultado = numero1 + numero2
        print("Resultado: ", resultado)
    
    elif opcion == 2:
        print("Elegiste restar")
        numero1 = int(input("Ingresa el primer número: "))
        numero2 = int(input("Ingresa el segundo número: "))
        resultado = numero1 - numero2
        print("Resultado: ", resultado)
    
    elif opcion == 3:
        print("Saliendo del programa...")

    else:
        print("Opción invalida.")
        print("Por favor elige una opción válida.")

