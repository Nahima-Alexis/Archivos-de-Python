entradas_disponibles=50
entradas_vendidas=0

while True:

    print("\n===== MENU =====")
    print("1.- Ver entradas disponibles")
    print("2.- Comprar entradas")
    print("3.- Devolver entradas")
    print("4.- Ver entradas vendidas")
    print("5.- Salir") 
    try:
        opcion=int(input("Seleccione opción : "))

        if opcion==1:
            print(f"Entradas Disponibles :  {entradas_disponibles}")
        elif opcion==2:
            if entradas_disponibles>0:
                try:
                    compra=int(input("Ingrese Cantidad de Entradas : "))
                    if compra <=0 :
                        print("Debe ingresar un valor positivo.")
                    elif compra > entradas_disponibles:
                        print("No puede superar el stock.")
                    else:
                        #entradas_disponibles=entradas_disponibles-compra
                        entradas_disponibles-=compra
                        entradas_vendidas+=compra
                        print(f"Compra realizada")
                except ValueError:
                    print("Error. Debe ingresar enteros.")
            else:
                print(f"Tenemos {entradas_disponibles} Entradas Disponibles, por lo que no se puede vender")
        elif opcion==3:
            if entradas_vendidas>0:
                try:
                    devolucion=int(input("Ingrese Cantidad a Devolver de Entradas :"))
                    if devolucion <= 0:
                        print("Debe ingresar un valor positivo.")
                    elif (entradas_disponibles+devolucion) > 50:
                        print("No puede superar el máximo total.")
                    else:
                        entradas_disponibles+=devolucion
                        entradas_vendidas-=devolucion

                        print(f" {devolucion} entradas devueltas con éxito")
                except ValueError:
                        print("Error. Debe ingresar enteros.")
                
            else:
                print(f"Tenemos {entradas_vendidas} Entradas Vendidas, por lo que no puede Devolver")
            print(f"Esta es la opción 3")
        elif opcion==4:
            print(f"Entradas Vendidas :  {entradas_vendidas}")
        elif opcion==5:
            print("Gracias por utilizar el sistema de Entradas para Concierto.")
            break
        else:
            print("Opción inválida.")        
    except ValueError:
       print("Debe ingresar un número entero.")  
