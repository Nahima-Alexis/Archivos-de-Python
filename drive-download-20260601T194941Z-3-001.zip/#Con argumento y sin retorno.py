#Con argumento y sin retorno
import os
os.system("cls")

def saludar_cliente(nombre_cliente):
    print(f"Bienvenido {nombre_cliente}, que vas a tomar hoy?")

saludar_cliente("Juan")