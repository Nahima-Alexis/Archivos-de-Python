#Tarifa de plan de internet y television
import os
pack_base = 35000
instalacion = 20000

os.system("cls")

tipo_cliente = input("Ingrese el tipo de cliente (N = Nuevo / A = Antiguo)").upper()
velocidad = input("Ingrese la velocidad contratada (B = Basica / E = Estandar / P = Premium)").upper()

if tipo_cliente == "N" and (velocidad == "B" or velocidad == "E"):
    descuento_pack = pack_base * 0.15

elif tipo_cliente == "N" and velocidad == "P":
    descuento_pack = pack_base * 0.10

elif tipo_cliente == "A" and (velocidad == "B" or velocidad == "E"):
    descuento_pack = pack_base * 0.10

elif tipo_cliente == "A" and velocidad == "P":
    descuento_pack = pack_base * 0.05

else:
    descuento_pack = 0

valor_pack_definitivo = pack_base - descuento_pack

if tipo_cliente == "N" and velocidad == "P":
    valor_instalacion = 0

elif tipo_cliente == "N":
    valor_instalacion = instalacion * 0.50

else:
    valor_instalacion = instalacion

print(f"El valor mensual del pack es: {int(valor_pack_definitivo)}")
print(f"El valor de la instalacion es: {int(valor_instalacion)}")
