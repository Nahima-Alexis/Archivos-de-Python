continuar = "si" #Preparación
lista_de_nacimientos = []

while continuar == "si": #Condición y bucle while
    try:
        edad = int(input("¿Cuántos años tienes?")) # Entrada
    except ValueError:
        print("ERROR! POR FAVOR INGRESA SOLO NUMEROS.")
        continue

    anio_actual = 2026
    anio_de_nacimiento = anio_actual - edad # Proceso
    lista_de_nacimientos.append(anio_de_nacimiento)

    print(f"Naciste en el año {anio_de_nacimiento}") # Salida

    if edad < 13:
        print("Eres un niño/a.")

    elif edad >= 65:
        print("Eres una persona mayor.")

    elif edad < 18:
        print("Eres un adolescente.")

    else:
        print("Eres una persona adulta.")
    print(" ")

    continuar = input("¿Deseas evaluar a otra persona? (si/no): ")
print(f"Los años de nacimientos procesados son: {lista_de_nacimientos}")
print(f"En total se evaluaron a {len(lista_de_nacimientos)} personas.")