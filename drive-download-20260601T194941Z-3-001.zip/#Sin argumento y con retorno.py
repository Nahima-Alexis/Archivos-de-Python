#Sin argumento y con retorno
import os
os.system("cls")

def revisar_cafe():
    kilos_cafe = 50
    return kilos_cafe

mi_reserva = revisar_cafe()
print(f"Mi reserva tiene {mi_reserva}")