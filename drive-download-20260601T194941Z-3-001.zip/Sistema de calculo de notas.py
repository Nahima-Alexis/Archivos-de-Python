import os
os.system("cls")

print("--- SISTEMA DE CÁLCULO DE NOTAS ---")

# 1. INPUT PARTE 1
# Pide las 3 notas al usuario (¡Acuérdate de usar float!)
ea1 = float(input("~ Ingresa la primera nota ~\nEA1 --> "))
print(" ")
ea2 = float(input("~ Ingresa la segunda nota ~\nEA2 --> "))
print(" ")
ea3 = float(input("~ Ingresa la tercera nota ~\nEA3 --> "))
print(" ")

# 2. PROCESO PARTE 1
# Calcula el promedio de presentación (EA1 vale 0.3, EA2 vale 0.4 y EA3 vale 0.3)
promedio_presentacion = (ea1 * 0.3) + (ea2 * 0.4) + (ea3 * 0.3)

# 3. OUTPUT PARTE 1
# Imprime el promedio de presentación redondeado a 1 decimal
print(f"El promedio de presentación final es: {promedio_presentacion:.1f}")
print(" ")

# 4. INPUT PARTE 2
# Pide la nota del examen al usuario
examen = float(input("~ Ingresa la nota del exámen ~\nNota del exámen --> "))
print(" ")

# 5. PROCESO PARTE 2
# Calcula el promedio final (Promedio de presentación vale 0.6 y el examen vale 0.4)
promedio_final = (promedio_presentacion * 0.6) + (examen * 0.4)

# 6. OUTPUT FINAL
# Imprime el promedio final redondeado a 1 decimal
print(f"El promedio final es: {promedio_final:.1f}")
print(" ")

if promedio_final >= 4.0:
     print("Aprobado/a")
else:
    print("Reprobado/a")
