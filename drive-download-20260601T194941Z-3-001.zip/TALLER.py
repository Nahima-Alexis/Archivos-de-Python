from random import randint

minimo = 100
maximo = 200
valor = randint(minimo, maximo)

base == 10
altura == 5
print(f"el area es (base * altura)")