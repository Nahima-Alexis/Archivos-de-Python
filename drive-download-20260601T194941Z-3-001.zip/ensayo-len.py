#Uso de len() y break
import os
os.system("cls")

nombre = "Nahima"
edad = 99
vuelta = 1
while nombre:
    print(f"Vuelta {vuelta}: Tu nombre es {nombre}, tienes {edad} años y tu nombre contiene {len(nombre)} letras.")
    
    vuelta = vuelta + 1
    
    if vuelta == 4:
        print("FRENO DE EMERGENCIA (break) ACTIVADO!!! Saliendo del bucle...")
        break