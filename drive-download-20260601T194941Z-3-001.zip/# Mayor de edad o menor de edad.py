# Mayor de edad o menor de edad
import os
os.system("cls")
edad = int(input("¿Cúal es tu edad?\nPor favor ingresa tu edad: "))

if edad >= 60:
    print(f"Tienes {edad}.\nEres adulto mayor.")
  
elif edad >= 18 and edad <= 59:
    print(f"Tienes {edad}.\nEres adulto.")  
    

else:
    print("Eres un menor de edad")

    