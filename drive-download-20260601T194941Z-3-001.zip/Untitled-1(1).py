import os
os.system("cls")

print("\n==== Bienvenido a la tienda de dulces====")
print("1.- Ver los dulces disponibles")
print("2.- Comprar dulces")
print("3.- Salir")

while True:
    print(" ")
    try:
        opcion = int(input("Seleccione una opción: "))
        print(f"Elegiste la opción {opcion}")

        if opcion == 1:
            print("Ver los dulces disponibles")

        elif opcion == 2:
            print("Comprar dulces")

        elif opcion == 3:
            print("Saliendo del programa...")
            break

        else:
            print("Opción inválida. \nElige una opción entre 1 - 3.")

    except ValueError:
        print("¡ERROR! Debes ingresar un NUMERO ENTERO.")
