import os

os.system("cls" if os.name == "nt" else "clear")

# PRECIOS
precio_pikachu_roll = 4500
precio_otaku_roll = 5000
precio_pulpo_venenoso_roll = 5200
precio_anguila_electrica_roll = 4800

# CANTIDADES
pikachu_roll = 0
otaku_roll = 0
pulpo_venenoso_roll = 0
anguila_electrica_roll = 0

salir = False

while not salir:

    print("\n=========== Tienda de Sushi ===========")
    print("Bienvenido a la tienda virtual de Sushi")
    print("------------------Menú-----------------")
    print("1.- Pikachu Roll = $4.500")
    print("2.- Otaku Roll = $5.000")
    print("3.- Pulpo Venenoso Roll = $5.200")
    print("4.- Anguila Eléctrica Roll = $4.800")
    print("5.- Finalizar compra")

    try:
        opcion_menu = int(input("Por favor, ingresa una opción:\n--> "))

        # AGREGAR PRODUCTOS
        if opcion_menu == 1:
            pikachu_roll += 1
            print("Has elegido 'Pikachu Roll'")

        elif opcion_menu == 2:
            otaku_roll += 1
            print("Has elegido 'Otaku Roll'")

        elif opcion_menu == 3:
            pulpo_venenoso_roll += 1
            print("Has elegido 'Pulpo Venenoso Roll'")

        elif opcion_menu == 4:
            anguila_electrica_roll += 1
            print("Has elegido 'Anguila Eléctrica Roll'")

        # FINALIZAR COMPRA
        elif opcion_menu == 5:

            productos = (
                pikachu_roll +
                otaku_roll +
                pulpo_venenoso_roll +
                anguila_electrica_roll
            )

            # VALIDAR CARRITO VACÍO
            if productos == 0:
                print("No has agregado productos.")
                continue

            print("Finalizando compra...")

            # CALCULAR SUBTOTAL
            subtotal = (
                precio_pikachu_roll * pikachu_roll +
                precio_otaku_roll * otaku_roll +
                precio_pulpo_venenoso_roll * pulpo_venenoso_roll +
                precio_anguila_electrica_roll * anguila_electrica_roll
            )

            descuento = 0
            volver_menu = False

            # DESCUENTO
            while True:

                respuesta_descuento = input(
                    "\n¿Tienes código de descuento?\n"
                    "Para 'Sí' escribe 's'\n"
                    "Para 'No' escribe 'n'\n--> "
                ).lower()

                if respuesta_descuento == "s":

                    codigo = input(
                        "Por favor, ingresa el código de descuento\nAqui --> "
                    ).lower()

                    if codigo == "soyotaku":
                        descuento = int(subtotal * 0.10)
                        print("Se ha aplicado un 10% de descuento.")
                        break

                    else:
                        print("Código no válido.")

                elif respuesta_descuento == "n":
                    break

                else:
                    print("Opción inválida.")
                    print("'R' Para volver a intentarlo")
                    print("'X' Para volver al menú principal")

                    opcion_descuento = input("Elige una opción: ").upper()

                    if opcion_descuento == "R":
                        continue

                    elif opcion_descuento == "X":
                        volver_menu = True
                        break

                    else:
                        print("Opción inválida.")

            # VOLVER AL MENÚ
            if volver_menu:
                continue

            # TOTAL
            total_final = subtotal - descuento

            # BOLETA
            print("\n*************************************************")
            print(f"TOTAL PRODUCTOS: {productos}")
            print("*************************************************")

            print(f"Pikachu Roll: {pikachu_roll}")
            print(f"Otaku Roll: {otaku_roll}")
            print(f"Pulpo Venenoso Roll: {pulpo_venenoso_roll}")
            print(f"Anguila Eléctrica Roll: {anguila_electrica_roll}")

            print("*************************************************")
            print(f"Subtotal por pagar: ${subtotal}")
            print(f"Descuento aplicado: ${descuento}")
            print(f"TOTAL: ${total_final}")
            print("\nGRACIAS POR TU COMPRA.")

            # NUEVO PEDIDO
            while True:

                try:
                    print("\n¿Desea realizar otro pedido?")
                    print("1.- Sí")
                    print("2.- Salir")

                    opcion_reinicio = int(input("Ingresa tu opción: "))

                    if opcion_reinicio == 1:

                        print("Volviendo al menú...")

                        pikachu_roll = 0
                        otaku_roll = 0
                        pulpo_venenoso_roll = 0
                        anguila_electrica_roll = 0

                        break

                    elif opcion_reinicio == 2:

                        salir = True
                        break

                    else:
                        print("Opción no válida.")

                except ValueError:
                    print("Debes ingresar un número.")

        else:
            print("Por favor, elige una opción válida.")

    except ValueError:
        print("¡ERROR! Por favor ingresa solo números enteros.")