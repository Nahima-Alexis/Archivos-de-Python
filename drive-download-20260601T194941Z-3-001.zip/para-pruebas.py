#Cons
import os
import time
import random

os.system("cls")
valr=random.randint(1,15)

print("\t Bienvenido al Juego Adivine El Numero")

valu=int(input("Por favor, adivine el numero ingresando un valor entre 1 y 15: "))
#if valu >= 1 and valu <= 15

if valu == valr:
    print(f"Felicitaciones, has adivinado el numero, que era {valr}!")
    time.sleep(2)
elif valu > valr:
    print(f"Oh... Tu numero era mayor que {valr}!")
    time.sleep(2)
else:
     print(f"Oh... Tu numero era menor que {valr}!")
     time.sleep(2)

print("Muchas gracias por jugar!")