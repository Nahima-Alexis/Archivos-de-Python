#Con argumento y con retorno
import os
os.system("cls")

def cobrar_pedido(precio, cantidad):
    total = precio * cantidad
    return total

dinero_ganado = cobrar_pedido(50, 2)

print(f"El dinero ganado es: {dinero_ganado}")