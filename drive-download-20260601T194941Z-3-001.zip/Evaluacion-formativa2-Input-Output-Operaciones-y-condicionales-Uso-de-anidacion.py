import os
os.system("cls")

num1 = int(input("Ingrese el primer número: "))
print(" ")
num2 = int(input("Ingrese el segundo número: "))
print(" ")
num3 = int(input("Ingrese el tercer número: "))
print(" ")

total_pares = 0
total_impares = 0

if num1 % 2 == 0:
    total_pares += 1
else:
    total_impares += 1

if num2 % 2 == 0:
    total_pares += 1
else:
    total_impares += 1

if num3 % 2 == 0:
    total_pares += 1
else:
    total_impares += 1

print(f"Hay {total_pares} numero(s) par(es) en total.")
print(" ")
print(f"Hay {total_impares} numero(s) impar(es) en total.")

print(" ")

total_numeros = num1 + num2 + num3
print(f"El total de los numeros es: {total_numeros}")

print(" ")

if total_numeros > 100:
    print("La suma total de los numeros es mayor a 100.")
    if total_numeros % 2 == 0:
        print("La suma es PAR.")
        print(" ")
    else:
        print("La suma de los numeros es IMPAR.")
        print(" ")