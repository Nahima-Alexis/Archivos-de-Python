
entradas_disponibles = 50
entradas_vendidas = 0

while True:
    print("\n==== MENU ====")
    print("1.- Ver entradas disponibles")
    print("2.- Comprar entradas")
    print("3.- Devolver entradas")
    print("4.- Ver entradas vendidas")
    print("5.- Salir")

    try:
        opcion = int(input("Seleccione una opción: "))

        if opcion == 1:
            print(f"Entradas disponibles: {entradas_disponibles}")
        elif opcion == 2:
            try:
                compra = int(input("Ingrese la cantidad de entradas: "))
                if compra <= 0:
                    print("Debe ingresar un valor positivo y mayor que 0.")
                elif compra > entradas_disponibles:
                    print("No puede superar el Stock Disponible.")
                else:
                    entradas_disponibles -= compra #este es el acumulador que refleja el total de entradas disponibles después de la compra
                    entradas_vendidas += compra #este es el acumulador que refleja el total de entradas vendidas
                    
                    print("Gracias por tu compra.")
            except ValueError:
                print("ERROR! DEBE INGRESAR NÚMEROS ENTEROS.")
    
        elif opcion == 3:
            if entradas_vendidas > 0:
                try:
                    devolucion = int(input("Cantidad a Devolver: "))
                    if devolucion <= 0:
                        print("Debe ingresar un valor positivo o mayor que 0.")
                    elif (devolucion > entradas_vendidas):
                        print("No puede superar el máximo total")
                    else:
                        entradas_disponibles += compra #este es el acumulador que refleja el total de entradas disponibles después de la compra
                        entradas_vendidas -= compra #este es el acumulador que refleja el total de entradas vendidas
                        print("Devolución realizada.")
                except ValueError:
                    print("ERROR! DEBE INGRESAR NÚMEROS ENTEROS.")
            else:
                print("No puede devolver entradas, ya que no se han vendido.")
        
        elif opcion == 4:
            print(f"Entradas vendidas: {entradas_vendidas}")
        elif opcion == 5:
            print("Gracias por utilizar el sitema de entradas para Concierto.")
            break
        else:
            print("Opción inválida.\nPor favor ingresa una opción valida")
    except ValueError:
        print("Debe ingresar un número entero.")        
        