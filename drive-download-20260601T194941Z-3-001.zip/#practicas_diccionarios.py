#practicas_diccionarios
persona = {
    "edad" : 31,
    "anio_de_nacimiento" : 1995,
    "categoria" : "persona adulta"
}
persona["nombre"] = "Nahima"
print(persona)
print(f"La categoria de la persona es: {persona['categoria']}")