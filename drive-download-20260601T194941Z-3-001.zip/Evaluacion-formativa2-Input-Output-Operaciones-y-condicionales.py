import os
os.system("cls")

nota_ea1 = float(input("Ingrese la nota de la EA1: "))
nota_ea2 = float(input("Ingrese la nota de la EA2: "))
nota_ea3 = float(input("Ingrese la nota de la EA3: "))

promedio_presentacion = (nota_ea1 * 0.30) + (nota_ea2 * 0.40) + (nota_ea3 * 0.30)

promedio_pres_redondeado = round(promedio_presentacion, 1)
print(f"El promedio de presentación final es: {promedio_pres_redondeado}")

nota_examen = float(input("\nIngrese la nota del examen: "))

promedio_final = (promedio_presentacion * 0.60) + (nota_examen * 0.40)

final_redondeado = round(promedio_final, 1)
print(f"El promedio final es: {final_redondeado}")