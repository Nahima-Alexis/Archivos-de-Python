# PSEUDOCODIGO - MAPA MENTAL
# 1. Mostrar menú con 4 rolls + opción para terminar pedido
# 2. Repetir (while True) hasta que el usuario termine su pedido (break)
# 3. Preguntar si tiene código de descuento (if/else)
#    3a. Si tiene código:
#        - Si es "soyotaku" → aplicar 10% de descuento
#        - Si no → mostrar "código no válido" 
#          y repetir (otro while) hasta que reingrese o escriba X
# 4. Mostrar detalle: cantidad de cada roll, subtotal, descuento y total final
# 5. Preguntar si desea otro pedido o salir
#-----------------------------------------------------------------------------------------------------------------------
import os
os.system("cls")

pikachu_roll = 0
otaku_roll = 0
pulpo_venenoso_roll = 0
anguila_electrica_roll = 0

precio_pikachu_roll = 4500
precio_otaku_roll = 5000
precio_pulpo_venenoso_roll = 5200
precio_anguila_electrica_roll = 4800

subtotal = 0
descuento = 0
total_final = 0

while True:
    print(" ")
    print("=========== Tienda de Sushi ===========")
    print("Bienvenido a la tienda virtual de Sushi")
    print("------------------Menú-----------------")
    print(" ")
    print("1.- Pikachu Roll = $4.500")
    print("2.- Otaku Roll = $5.000")
    print("3.- Pulpo Venenoso Roll = $5.200")
    print("4.- Anguila Eléctrica = $4.800")
    print("5.- Finalizar compra")
    
    try:
        opcion = int(input("Por favor, ingresa una opción:\n--> "))
        
        if opcion == 1:
            pikachu_roll += 1
            print("Has elegido 'Pikachu Roll'")
        
        elif opcion == 2:
            otaku_roll += 1
            print("Has elegido 'Otaku Roll'")
            
        elif opcion == 3:
            pulpo_venenoso_roll += 1
            print("Has elegido 'Pulpo Venenoso Roll'")
            
        elif opcion == 4:
            anguila_electrica_roll += 1
            print("Has elegido 'Anguila Eléctrica Roll'")
            
        elif opcion == 5:
            print("Finalizando compra...")
            break
    
        else:
            print("Por favor, elige una opción válida dentro del menú.")
            
    except ValueError:
        print("¡ERROR! Por favor ingresa solo números enteros.")  
    
while True:
    codigo_de_descuento = input("¿Tienes código de descuento?\nPara 'Si' escribe 's'\nPara 'No' escribe 'n'\n--> ")
    if codigo_de_descuento == "s":
        codigo_de_descuento = input("Por favor, ingresa el codigo de descuento\nAqui --> ")
        if codigo_de_descuento == "soyotaku":
            print("Se ha aplicado un 10% de descuento al total de tu compra.")
            break
        else:
            print("Codigo no valido.")
    elif codigo_de_descuento == "n":
        break
    else:
        print("Codigo invalido.")
        print("R Para volver a intentarlo\nX para volver al menu principal")
        opcion = input("Elige una opcion: ")
        if opcion == "R":
            continue
        elif opcion == "X":
            break
            
                
            
          